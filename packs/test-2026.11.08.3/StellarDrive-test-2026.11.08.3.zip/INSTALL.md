# StellarDrive Test client pack

Pack test-2026.11.08.3 matches the Test stack observed November 8, 2026
at 10:25 p.m. EST. Live client join verification is pending.

## Prepare the Mods folder

1. Use StellarDrive Demo 0.8.2 and MelonLoader 0.7.3 Mono x64.
2. Extract this ZIP into its own folder.
3. From PowerShell in the extracted folder, run .\Complete-Test-Pack.ps1.
   It downloads the 17 pinned author archives and verifies all 30 DLLs,
   then prepares Ready/Mods beside the script. The Mod Manager v1.1.1
   release contains the exact DLL that reports v1.1.0 on Test.
4. With the game closed, back up your current Mods folder. Use Ready/Mods as
   the clean Test set. Keep your previous Mods folder for switching servers.
5. Launch the game and join Test normally. Keep the exact versions from the pack.

The JSON manifest lists the filename, version, source and SHA-256 of each DLL.
Unlimited Players is a host-side mod. The separate Sandbox admin bridge is
for authorized users who need item grants. This pack includes the advertised
original Sandbox Menu DLL through its author's release.

This revision adds the stock Crouch mod and Ground Altimeter from Test. The pack targets the normal player client. Profiling tools, experimental client-only fixes and the Sandbox admin bridge are separate installs.
