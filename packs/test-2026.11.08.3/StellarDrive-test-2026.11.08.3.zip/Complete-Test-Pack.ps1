# Prepare an exact Test Mods folder beside this script. Run from an extracted ZIP.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$manifest = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') | ConvertFrom-Json

function Assert-Artifact($path, $entry) {
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer -or $item.Length -ne $entry.size -or
        (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash -ine $entry.sha256) {
        throw "Size or SHA-256 mismatch for $($entry.file)."
    }
}

$output = Join-Path $PSScriptRoot 'Ready'
if (Test-Path -LiteralPath $output) {
    throw 'Ready already exists. Extract a fresh copy of this pack to prepare it again.'
}
$staging = Join-Path $PSScriptRoot ('.prepare-' + [Guid]::NewGuid().ToString('N'))
$mods = Join-Path $staging 'Mods'
$archivePath = Join-Path $staging 'dependency.zip'
New-Item -ItemType Directory -Path $mods | Out-Null
try {
    foreach ($entry in $manifest.mods) {
        if ($entry.file -notmatch '^[A-Za-z0-9._-]+[.]dll$') {
            throw 'Invalid DLL filename in manifest.'
        }
        $target = Join-Path $mods $entry.file
        switch ($entry.delivery) {
            'bundled' { Copy-Item -LiteralPath (Join-Path $PSScriptRoot "Mods/$($entry.file)") -Destination $target }
            'upstream' {
                $url = [Uri]$entry.download
                if ($url.Scheme -ne 'https' -or $url.Host -ne 'github.com' -or
                    $url.AbsolutePath -notmatch '^/[^/]+/[^/]+/releases/download/[^/]+/[^/]+$') {
                    throw 'Expected a pinned GitHub release URL.'
                }
                Write-Host "Fetching $($entry.file) $($entry.version)"
                Invoke-WebRequest -Uri $url -UseBasicParsing -OutFile $archivePath
                $zip = [IO.Compression.ZipFile]::OpenRead($archivePath)
                try {
                    $members = @($zip.Entries | Where-Object {
                        $_.FullName.Replace([char]92, [char]47) -ceq $entry.member
                    })
                    if ($members.Count -ne 1 -or $members[0].Length -ne $entry.size) {
                        throw "Expected a single archive member of the correct size for $($entry.file)."
                    }
                    [IO.Compression.ZipFileExtensions]::ExtractToFile($members[0], $target)
                } finally {
                    $zip.Dispose()
                    Remove-Item -LiteralPath $archivePath
                }
            }
            default { throw "Unknown delivery type for $($entry.file)." }
        }
        Assert-Artifact $target $entry
    }
    [IO.Directory]::Move($staging, $output)
    Write-Host "Verified $($manifest.mods.Count) DLLs under $output\Mods"
} catch {
    # Leave only this run's staging directory for inspection after a failure.
    Write-Warning "Pack preparation stopped. Partial files are in $staging."
    throw
}
