# Install StellarDrive Test mods

1. Close StellarDrive. Extract this ZIP into its own folder.
2. Double-click **Install Test Mods.cmd**. Confirm the folder containing
   StellarDrive.exe. For a custom Steam library, enter its game folder.
3. Confirm installation. The installer downloads the pinned upstream DLLs,
   verifies all files, and backs up your existing Mods folder before installing.
4. Start StellarDrive and join Test.

Use StellarDrive Demo 0.8.2 and MelonLoader 0.7.3 Mono x64. The installer
prints the backup location. To restore it, close the game, move the new Mods
folder aside, then rename the backup to Mods.
