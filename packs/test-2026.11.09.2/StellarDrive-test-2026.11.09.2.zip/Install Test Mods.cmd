@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Test-Mods.ps1"
set "result=%errorlevel%"
if not "%result%"=="0" echo Installation stopped. See the message above.
pause
exit /b %result%
