# Install the verified Test mod set from an extracted ZIP.
param([switch]$PrepareOnly)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$manifest = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') | ConvertFrom-Json
if ($manifest.schema -ne 1 -or $manifest.channel -cne 'Test' -or !$manifest.mods) {
    throw 'Expected a Test pack manifest with at least one DLL.'
}

function Assert-Artifact($path, $entry) {
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer -or $item.Length -ne $entry.size -or
        (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash -ine $entry.sha256) {
        throw "Size or SHA-256 mismatch for $($entry.file)."
    }
}

function Get-PinnedArchive($url, $path, $name, [switch]$ApiAsset) {
    $headers = @()
    if ($ApiAsset) { $headers = @('-H', 'Accept: application/octet-stream') }
    for ($attempt = 1; $attempt -le 4; $attempt++) {
        Write-Host "Downloading $name (attempt $attempt of 4)"
        $err = & curl.exe --fail --silent --show-error --location --proto '=https' --proto-redir '=https' --connect-timeout 8 --max-time 30 --output $path @headers $url.AbsoluteUri 2>&1
        if ($LASTEXITCODE -eq 0) { return }
        if ("$err" -match 'error: 40\d\d') { break }
        if ($attempt -lt 4) { Start-Sleep -Seconds (5 * $attempt) }
    }
    throw "Could not download $name from GitHub. Check your connection and try again. Your active Mods folder has not been moved."
}

function Assert-GameClosed {
    if (Get-Process -Name 'StellarDrive' -ErrorAction SilentlyContinue) {
        throw 'Close StellarDrive before installing Test mods.'
    }
}

function Get-ExistingMods($path) {
    $item = Get-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
    if ($item -and (!$item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint))) {
        throw "Expected a regular Mods folder at $path."
    }
    return $item
}

$destination = $PSScriptRoot
if ($PrepareOnly) {
    $output = Join-Path $destination 'Ready'
    if (Test-Path -LiteralPath $output) { throw 'Ready already exists. Use a fresh extraction.' }
} else {
    Assert-GameClosed
    $steamPath = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -Name SteamPath -ErrorAction SilentlyContinue).SteamPath
    $default = if ($steamPath) { Join-Path $steamPath 'steamapps/common/StellarDrive Demo' }
    $answer = (Read-Host "StellarDrive Demo folder [$default]").Trim().Trim('"')
    if (!$answer) { $answer = $default }
    if (!$answer -or !(Test-Path -LiteralPath (Join-Path $answer 'StellarDrive.exe') -PathType Leaf)) {
        throw 'Choose the game folder that contains StellarDrive.exe.'
    }
    $destination = (Get-Item -LiteralPath $answer).FullName
    $output = Join-Path $destination 'Mods'
    $null = Get-ExistingMods $output
    if ((Read-Host "Replace $output with Test pack $($manifest.pack)? [y/N]") -ine 'y') {
        Write-Host 'Installation cancelled.'
        return
    }
}
$staging = Join-Path $destination ('.test-pack-' + [Guid]::NewGuid().ToString('N'))
$mods = Join-Path $staging 'Mods'
$archivePath = Join-Path $staging 'dependency.zip'
New-Item -ItemType Directory -Path $mods | Out-Null
try {
    $seen = @{}
    foreach ($entry in $manifest.mods) {
        if ($entry.file -notmatch '^[A-Za-z0-9._-]+[.]dll$' -or $seen.ContainsKey($entry.file)) {
            throw 'Invalid or duplicate DLL filename in manifest.'
        }
        $seen[$entry.file] = $true
        $target = Join-Path $mods $entry.file
        switch ($entry.delivery) {
            'bundled' { Copy-Item -LiteralPath (Join-Path $PSScriptRoot "Mods/$($entry.file)") -Destination $target }
            'upstream' {
                $existing = if (!$PrepareOnly) {
                    $candidate = Get-Item -LiteralPath (Join-Path $output $entry.file) -Force -ErrorAction SilentlyContinue
                    if ($candidate -and !$candidate.PSIsContainer -and
                        !($candidate.Attributes -band [IO.FileAttributes]::ReparsePoint) -and
                        $candidate.Length -eq $entry.size -and
                        (Get-FileHash -Algorithm SHA256 -LiteralPath $candidate.FullName).Hash -ieq $entry.sha256) {
                        $candidate
                    }
                }
                if ($existing) {
                    Write-Host "Reusing verified $($entry.file)"
                    Copy-Item -LiteralPath $existing.FullName -Destination $target
                    Assert-Artifact $target $entry
                    continue
                }
                $url = [Uri]$entry.download
                if ($url.Scheme -ne 'https' -or $url.Host -ne 'github.com' -or
                    $url.AbsolutePath -notmatch '^/[^/]+/[^/]+/releases/download/[^/]+/[^/]+$') {
                    throw 'Expected a pinned GitHub release URL.'
                }
                $parts = [regex]::Match($url.AbsolutePath, '^/([^/]+)/([^/]+)/releases/download/')
                $api = $null
                if ($entry.assetId -and $parts.Success) {
                    $api = [Uri]("https://api.github.com/repos/$($parts.Groups[1].Value)/$($parts.Groups[2].Value)/releases/assets/$($entry.assetId)")
                }
                if ($api) {
                    try {
                        Get-PinnedArchive $api $archivePath $entry.file -ApiAsset
                    } catch {
                        Get-PinnedArchive $url $archivePath $entry.file
                    }
                } else {
                    Get-PinnedArchive $url $archivePath $entry.file
                }
                $zip = [IO.Compression.ZipFile]::OpenRead($archivePath)
                try {
                    $members = @($zip.Entries | Where-Object {
                        $_.FullName.Replace([char]92, [char]47) -ceq $entry.member
                    })
                    if ($members.Count -ne 1 -or $members[0].Length -ne $entry.size) {
                        throw "Expected a single archive member of the correct size for $($entry.file)."
                    }
                    [IO.Compression.ZipFileExtensions]::ExtractToFile($members[0], $target)
                } finally {
                    $zip.Dispose()
                    Remove-Item -LiteralPath $archivePath
                }
            }
            default { throw "Unknown delivery type for $($entry.file)." }
        }
        Assert-Artifact $target $entry
    }
    if ($PrepareOnly) {
        [IO.Directory]::Move($staging, $output)
        Write-Host "Verified $($seen.Count) DLLs under $output\Mods"
    } else {
        Assert-GameClosed
        $backup = $null
        if (Get-ExistingMods $output) {
            $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
            $backup = Join-Path $destination ("Mods - backup $stamp " + [IO.Path]::GetFileName($staging).Substring(11, 8))
            [IO.Directory]::Move($output, $backup)
            Write-Host "Previous Mods folder: $backup"
        }
        try {
            [IO.Directory]::Move($mods, $output)
        } catch {
            if ($backup -and !(Test-Path -LiteralPath $output)) {
                [IO.Directory]::Move($backup, $output)
            }
            throw
        }
        [IO.Directory]::Delete($staging)
        Write-Host "Installed $($seen.Count) verified DLLs under $output"
    }
} catch {
    # Leave only this run's staging directory for inspection after a failure.
    Write-Warning "Pack preparation stopped. Partial files are in $staging."
    throw
}
